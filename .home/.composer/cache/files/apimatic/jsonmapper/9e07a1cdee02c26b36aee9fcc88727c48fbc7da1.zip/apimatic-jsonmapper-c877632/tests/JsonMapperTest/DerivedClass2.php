<?php

/**
 * @discriminator type
 * @discriminatorType derived2
 */
class JsonMapperTest_DerivedClass2 extends JsonMapperTest_DerivedClass
{
	public $derived2Field;
}
