
# Card Square Product

## Enumeration

`CardSquareProduct`

## Fields

| Name |
|  --- |
| `UNKNOWN_SQUARE_PRODUCT` |
| `CONNECT_API` |
| `DASHBOARD` |
| `REGISTER_CLIENT` |
| `BUYER_DASHBOARD` |
| `WEB` |
| `INVOICES` |
| `GIFT_CARD` |
| `VIRTUAL_TERMINAL` |
| `READER_SDK` |
| `SQUARE_PROFILE` |

