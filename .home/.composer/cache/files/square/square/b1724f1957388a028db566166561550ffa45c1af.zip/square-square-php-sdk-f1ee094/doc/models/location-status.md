
# Location Status

A location's status.

## Enumeration

`LocationStatus`

## Fields

| Name | Description |
|  --- | --- |
| `ACTIVE` | A location that is active for business. |
| `INACTIVE` | A location that is not active for business. Inactive locations provide historical<br>information. Hide inactive locations unless the user has requested to see them. |

