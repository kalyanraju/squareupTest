
# Booking Creator Details Creator Type

Supported types of a booking creator.

## Enumeration

`BookingCreatorDetailsCreatorType`

## Fields

| Name | Description |
|  --- | --- |
| `TEAM_MEMBER` | The creator is of the seller type. |
| `CUSTOMER` | The creator is of the buyer type. |

