
# Measurement Unit Generic

## Enumeration

`MeasurementUnitGeneric`

## Fields

| Name | Description |
|  --- | --- |
| `UNIT` | The generic unit. |

