
# Gift Card Activity Block Reason

## Enumeration

`GiftCardActivityBlockReason`

## Fields

| Name | Description |
|  --- | --- |
| `CHARGEBACK_BLOCK` | The gift card is blocked because the buyer initiated a chargeback on the gift card purchase. |

