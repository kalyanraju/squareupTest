
# Employee Status

The status of the Employee being retrieved.

## Enumeration

`EmployeeStatus`

## Fields

| Name | Description |
|  --- | --- |
| `ACTIVE` | Specifies that the employee is in the Active state. |
| `INACTIVE` | Specifies that the employee is in the Inactive state. |

