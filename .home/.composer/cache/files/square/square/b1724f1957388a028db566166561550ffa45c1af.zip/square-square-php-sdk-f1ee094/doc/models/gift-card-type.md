
# Gift Card Type

Indicates the gift card type.

## Enumeration

`GiftCardType`

## Fields

| Name | Description |
|  --- | --- |
| `PHYSICAL` | A plastic gift card. |
| `DIGITAL` | A digital gift card. |

