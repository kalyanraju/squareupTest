
# Application Details External Square Product

A list of products to return to external callers.

## Enumeration

`ApplicationDetailsExternalSquareProduct`

## Fields

| Name |
|  --- |
| `APPOINTMENTS` |
| `ECOMMERCE_API` |
| `INVOICES` |
| `ONLINE_STORE` |
| `OTHER` |
| `RESTAURANTS` |
| `RETAIL` |
| `SQUARE_POS` |
| `TERMINAL_API` |
| `VIRTUAL_TERMINAL` |

